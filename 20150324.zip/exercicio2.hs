maior :: Int -> Int -> Int -> Int
maior a b c
		| (a >= b) && (a >= c) = a
		| (b >= a) && (b >= c) = b
		| otherwise = c

menor :: Int -> Int -> Int -> Int
menor a b c
		| (a <= b) && (a <= c) = a
		| (b <= a) && (b <= c) = b
		| otherwise = c

meio :: Int -> Int -> Int -> Int
meio a b c
		| (a>=b) && (a <= c) || (a >= c) && (a<=b) = a
		| (b>=a) && (b <= c) || (b >= c) && (b<=a) = b
		| otherwise = c

ordenaTripla :: (Int, Int, Int) -> (Int, Int, Int)
ordenaTripla (a,b,c) = (menor a b c, meio a b c, maior a b c)