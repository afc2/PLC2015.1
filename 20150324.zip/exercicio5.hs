type Pessoa = String
type Livro = String
type BancoDados = [(Pessoa, String)]

baseExemplo :: BancoDados
baseExemplo =  [("Sergio","O Senhor dos Aneis"),("Andre","Duna"), ("Fernando","Jonathan Strange & Mr.Norrell"),  ("Fernando","A Game of Thrones")]

membro :: [Int] -> Int -> Bool
membro ls m = (length [x | x <- ls, x==m]) > 0

livros :: BancoDados -> Pessoa -> [Livro]
livros ls pp = [l | (p,l) <- ls, pp ==p]

emprestimos :: BancoDados -> Livro -> [Pessoa]
emprestimos ls ll = [p | (p,l) <- ls, ll ==l]

emprestado :: BancoDados -> Livro -> Bool
emprestado ls ll = (length (emprestimos ls ll)) >= 1

qtdEmprestimos :: BancoDados -> Pessoa -> Int
qtdEmprestimos ls pp = length (emprestimos ls pp)

devolver :: BancoDados -> Pessoa -> Livro -> BancoDados
devolver ls pp ll = [curr | curr <- ls , (fst(curr) /= pp) && (snd(curr) /= ll)]

quickSort :: [Int] -> [Int]
quickSort [] = []
quickSort (p:l) = quickSort [y | y <- l, y < p] ++ [p] ++ quickSort [x | x <- l, x >= p]