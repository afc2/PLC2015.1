type Ponto = (Float, Float)
type Reta = (Ponto, Ponto)

firstCoord :: Ponto -> Float
firstCoord (x,y) = x

secondCoord :: Ponto -> Float
secondCoord (x,y) = y

isVertical :: Reta -> Bool
isVertical ((x1,y1),(x2,y2))
		| x1 == x2 = True
		| otherwise = False

pontoY :: Float -> Reta -> Float
pontoY x ((x1, y1),(x2,y2)) = (x - x1) * (y2 - y1) / (x2 -x1) + y1