maior :: Int -> Int -> Int -> Int
maior a b c
		| (a >= b) && (a >= c) = a
		| (b >= a) && (b >= c) = b
		| otherwise = c

menor :: Int -> Int -> Int -> Int
menor a b c
		| (a <= b) && (a <= c) = a
		| (b <= a) && (b <= c) = b
		| otherwise = c

menorMaior :: Int -> Int -> Int -> (Int,Int)
menorMaior a b c = (menor a b c , maior a b c) 
