type Pessoa = String
type Livro = String
type BancoDados = [(Pessoa, String)]

baseExemplo :: BancoDados
baseExemplo =  [("Sergio","O Senhor dos Aneis"),("Andre","Duna"), ("Fernando","Jonathan Strange & Mr.Norrell"),  ("Fernando","A Game of Thrones")]

livros :: BancoDados -> Pessoa -> [Livro]
livros [] pp = []
livros ((p,l):as) pp
	| p == pp = l:livros as pp
	| otherwise = livros as pp

emprestimos :: BancoDados -> Livro -> [Pessoa]
emprestimos [] ll = []
emprestimos ((p,l):as) ll
	| l == ll = p:emprestimos as ll
	| otherwise = emprestimos as ll

emprestado :: BancoDados -> Livro -> Bool
emprestado [] ll = False
emprestado ((p,l):as) ll
	| l == ll = True
	| otherwise = emprestado as ll

qtdEmprestimos :: BancoDados -> Pessoa -> Int
qtdEmprestimos [] pp = 0
qtdEmprestimos ((p,l):as) pp
	| p == pp = 1 + qtdEmprestimos as pp
	| otherwise = qtdEmprestimos as pp

emprestar :: BancoDados -> Pessoa -> Livro -> BancoDados
emprestar bd p l
	| not (emprestado bd l) = bd ++ [(p,l)]
	| otherwise = bd

devolver :: BancoDados -> Pessoa -> Livro -> BancoDados
devolver [] pp ll = []
devolver ((p,l):as) pp ll
	| p == pp && l == ll = as
	| otherwise = (p,l):(devolver as pp ll)

membro :: [Int] -> Int -> Bool
membro ls m = (length [x | x <- ls, x==m]) > 0

livros :: BancoDados -> Pessoa -> [Livro]
livros ls pp = [l | (p,l) <- ls, pp ==p]

emprestimos :: BancoDados -> Livro -> [Pessoa]
emprestimos ls ll = [p | (p,l) <- ls, ll ==l]

emprestado :: BancoDados -> Livro -> Bool
emprestado ls ll = [l | (p,l) <- ls, ll = l] == ll

qtdEmprestimos :: BancoDados -> Pessoa -> Int
devolver :: BancoDados -> Pessoa -> Livro -> BancoDados