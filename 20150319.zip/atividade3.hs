member :: [Int] -> Int -> Bool

member l m
	| l == [] = False
	| (head l) == m = True 
	| otherwise member(tail l, m)