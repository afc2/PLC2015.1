sumPairs :: [Int] -> [Int] -> [Int]

sumPairs l1 l2
	| l1 == [] = []
	| l2 == [] = []
	| otherwise = [(head l1) + (head l2)] ++ sumPairs (tail l1) (tail l2)