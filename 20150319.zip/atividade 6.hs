biggerthan :: Int -> [Int] -> [Int]

biggerthan p l
		| l == [] = []
		| (head l) >= p = [head l] ++ biggerthan p (tail l)
		| otherwise = biggerthan p (tail l)

smallerthan :: Int -> [Int] -> [Int]

smallerthan p l
		| l == [] = []
		| (head l) < p = [head l] ++ smallerthan p (tail l)
		| otherwise = smallerthan p (tail l)

quicksort :: [Int] -> [Int]

quicksort l
		| l == [] = [] 
		| otherwise = quicksort ( smallerthan (head l) (tail l)) ++ [head l] ++ quicksort (biggerthan (head l) (tail l))