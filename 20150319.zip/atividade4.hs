digits :: String -> String

digits s | s == [] = []
		 | (head s >= '0') && (head s<= '9') = [(head s)] ++ digits (tail s)
	     | otherwise = digits (tail s)
	