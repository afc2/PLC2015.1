doubleList :: [Int] -> [Int]

doubleList as
	| as == [] = []
	| (tail as) == [] = [(head as * 2)]
	| otherwise = [(2 * head as)] ++ (tail as)