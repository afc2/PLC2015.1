takes :: [t] -> Int -> [t]
takes ls 0 = []
takes ls n = [(head ls)] ++ takes (tail ls) (n-1)

drops :: [t] -> Int -> [t]
drops [] n = []
drops ls n
	| n > 0 = drops (tail ls) (n-1)
	| otherwise = (head ls : drops (tail ls) (n-1))

takeWhiles :: (t -> Bool) -> [t] -> [t]  
takeWhiles pred [] = []  
takeWhiles pred ls
	| pred (head ls) == True = (head ls : takeWhiles pred (tail ls))
	| otherwise = []

dropWhiles :: (t->Bool) -> [t] -> [t]
dropWhiles pred [] = []
dropWhiles pred ls
	| pred (head ls) = dropWhiles pred (tail ls)
	| otherwise = ls

quickSort :: (Ord t) => [t] -> [t]
quickSort [] = []
quickSort (p:l) = quickSort [y | y <- l, y < p] ++ [p] ++ quickSort [x | x <- l, x >= p]
