fib :: Int -> Int
fib n
    | n < 2 = n
    | otherwise = (fib (n-1)) + (fib (n-2))

fibAux :: Int -> Int -> [Int]
fibAux 0 _ = []
fibAux n x 
    | ((mod fibonacci 2) == 0) = fibonacci : fibAux (n-1) (x+1)
    | otherwise = fibAux n (x+1)
 where fibonacci = (fib x)

fibPar :: Int -> [Int]
fibPar n = fibAux n 0

quickSortDigits :: [Int] -> [Int]
quickSortDigits [] = []
quickSortDigits (pivot:list) = quickSortDigits [y | y <- list, sumDigits (y) < sumDigits (pivot)] ++ [pivot] ++ quickSortDigits [y | y <- list, sumDigits (y) >= sumDigits (pivot)]

sumDigits :: Int -> Int
sumDigits a 
	| a == 0 = 0
    | otherwise = mod a 10 + sumDigits (div a 10)

agrupar :: (Eq t) => [[t]] -> [(t, Int)]
agrupar x = count (concat x)

count :: (Eq t) => [t] -> [(t, Int)]
count [] = []
count l@(x:xs) = [(x, length ([a | a <- l, a == x]))] ++ count [a | a <- l, a /= x]

data Tree t = NilT | Node t (Tree t) (Tree t) deriving (Eq, Show)

bfs :: Eq t => Tree t -> t -> Bool
bfs NilT n = False
bfs (Node v e d) n
 | v == n = True
 | otherwise = (||) (bfs e n) (bfs d n)
 
mapTree :: (t -> u) -> Tree t -> Tree u
mapTree f NilT = NilT
mapTree f (Node v e d) = (Node (f v) (mapTree f e) (mapTree f d))

e1 :: [[Int]] -> Int -> [[Int]]
e1 a v = filter (funca) a where funca x = ((foldr (+) 0 (x)) >= v)

existe :: [Int] -> Int -> Bool
existe [] _ = False
existe a i | head a == i = True
           | otherwise = existe (tail a) i 

add ::[Int] -> [Int] -> [Int]
add a b = filter (f) (a++b) where f x = ((existe a x) && ( existe b x))

final :: [Int] -> [Int]
final [] = []
final a | existe (tail a) (head a) = final (tail a)
        | otherwise = [head a] ++ final (tail a) 

inter :: [Int] -> [Int] -> [Int]
inter a b = final (add a b)

add2 ::[Int] -> [Int] -> [Int]
add2 a b = filter (f) (a++b) where f x = ((existe a x) && not( existe b x))

differ:: [Int] -> [Int] -> [Int]
differ a b = final (add2 a b)

f a b = (a > b)

g k = (\s l -> (k l s))

paresPrim = (\a -> map (fst) a)

listas =(\a b -> filter( ((>b).length)  ) a)

duplicados ::(Eq t)=> [t] -> [t]
duplicados [] = []
duplicados (x:xs) | not (elem x xs) = (x:(duplicados (xs)))
                  | otherwise = (duplicados (xs))

junta :: (Eq t) => ([[t]]->[t])
junta = (\a ->  duplicados(foldr (++) [] a) )

addAll :: (Num t)=> t -> ([t]-> [t])
addAll v = (\l ->map (+v) l)

mapfold :: (a1 -> a -> a) -> [a] -> [[a1] -> a]
mapfold fun l = [(f x) | x <- l]
	where
		f n [] = n
		f n (a:as) = f (fun a n) as

maxAll :: Ord t => ([t] -> t)
maxAll = (\x -> foldr (max) (minimum x) x)
